-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: localhost    Database: milestone_4_smmuja
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `role` enum('User','Admin') DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'dummy1','dummy1@email.com','$2b$12$nboIL0JH5yQUjRNtj2O9z.PEx3PA2wu1mK1/7o.9ZuSXn6byMjkDe','2024-03-12 04:21:24','2024-03-12 04:21:24',NULL),(2,'dummy1','dummy1@email.com','$2b$12$RmYWQAjbtndobTg.4txjD.eaMybW0twu9LwLxI4i8pFpbML.Ptlqy','2024-03-12 04:22:36','2024-03-12 04:22:36',NULL),(3,'dummy1','dummy1@email.com','$2b$12$EqC4GKabfy.Okz6BM9/oPOAGcRbNOzBahXr4e4ckE/kmaz3F2SHv6','2024-03-12 04:23:06','2024-03-12 04:23:06',NULL),(4,'dummy2','dummy2@email.com','$2b$12$UHoqhYbacnkBf0fC3AHNc.jtC6gAECOmuA5rPVnef0kmpqcXNzjCS','2024-03-12 04:24:06','2024-03-12 04:24:06',NULL),(5,'dummy1','dummy1@email.com','$2b$12$HYzeG2uZr8n05iUN18K89.iuIEwRBq2Ek7KC1koSfrVD8EzEoPHsi','2024-03-12 04:55:32','2024-03-12 04:55:32',NULL),(6,'dummy1','dummy1@email.com','$2b$12$xrOqXQlRob1KYoPtdSu3ku5XmyiKMP0LqGYnS9j9ww5kHrbMcYMAK','2024-03-12 04:56:37','2024-03-12 04:56:37',NULL),(7,'dummy1','dummy1@email.com','$2b$12$cLxtDCAMGAtTGQyqTMCGPOy4Px/jQNKriof2vn5SZ1GKTRU4oZjIq','2024-03-12 04:57:07','2024-03-12 04:57:07',NULL),(8,'dummy1','dummy1@email.com','$2b$12$bvUwubqg6deDdj8hEFlaruElJRQvVqaY2Q/7CdBJTNkNVolAEb5Lm','2024-03-12 04:57:27','2024-03-12 04:57:27',NULL),(9,'dummy1','dummy1@email.com','$2b$12$lNSwhGTBWJwknHXqoQB5a.4m78q0cSV1c3v0pws7w9yxRgcTHW1CC','2024-03-12 04:58:24','2024-03-12 04:58:24',NULL),(10,'dummy1','dummy1@email.com','$2b$12$yvPgZnplyI9arAgq3P/DFel8QANyLsI1G9Fy7Us809dhWFdHrfWQ6','2024-03-12 04:58:27','2024-03-12 04:58:27',NULL),(11,'dummy1','dummy1@email.com','$2b$12$U7mdvzY/G4fr8K3tVm46JuHWcdRh/gtWGpnkWxpPSVi1aLlYXzLVS','2024-03-12 04:58:40','2024-03-12 04:58:40',NULL),(12,'dummy1','dummy1@email.com','$2b$12$ukkQxlEMnTQ6b4macmpEIuzesWoLebLyXGvDRHfWgaO1l1efthywS','2024-03-12 05:03:21','2024-03-12 05:03:21',NULL),(13,'dummy1','dummy1@email.com','$2b$12$YUKoLx0ucbUFPTxrbNMAdeVbZ9f3KtE0Hu3JZkNb7Gbfyj/cQrSVe','2024-03-12 05:09:15','2024-03-12 05:09:15',NULL),(14,'dummy1','dummy1@email.com','$2b$12$U9vGiYMmq9eC8O/0r2kZG.Zusw0dVamlTtdDT/aEw2dzjfmrFpEAq','2024-03-12 05:09:24','2024-03-12 05:09:24',NULL),(15,'dummy1','dummy1@email.com','$2b$12$RFDTxcgsUJxdKkLoMnezgeGQarMOq/FwUPYCxgMZ3RgMbFY7cWFui','2024-03-12 05:13:04','2024-03-12 05:13:04',NULL),(16,'dummy1','dummy1@email.com','$2b$12$J18iZX4GRxkgEGJe4JAm9.YaAbomdioTl6QMOx/XSwBNF7jksNIqO','2024-03-12 05:13:17','2024-03-12 05:13:17',NULL),(17,'dummy1','dummy1@email.com','$2b$12$wRNJS0Aj1LX5dIcp00J1mu6kiIBhYmCNCUwcweY9gZAnP6u9QjZFq','2024-03-12 05:13:39','2024-03-12 05:13:39',NULL),(18,'dummy1','dummy1@email.com','$2b$12$/hxWvTozpxv6lGsWdAePO.d5Rqpnlzs5Y8GN69ar1gL4gU9gWEvny','2024-03-12 05:13:53','2024-03-12 05:13:53',NULL),(19,'dummy1','dummy1@email.com','$2b$12$Lza/h7oZ6V8Yd3T7epE0Pe3oq3SQVOz6c6BFTGVT35meRGSXZbN0a','2024-03-12 05:30:20','2024-03-12 05:30:20',NULL),(20,'dummy1','dummy1@email.com','$2b$12$yac.IuaOnS2Jg7n5Ii.iUuzfQasYmP9sm0UU1vR6Llut1EfZbdamC','2024-03-12 05:32:07','2024-03-12 05:32:07',NULL),(21,'dummy1','dummy1@email.com','$2b$12$/Q5tlOxByMblsDdAHfMWuuIc9pozJ9HF./tzW4xiKu3QaIVjWdBeq','2024-03-12 05:32:19','2024-03-12 05:32:19',NULL),(22,'dummy1','dummy1@email.com','$2b$12$9k8OkWsL2Jl1DrhobyhZreDlaIpRDZ//ZSg7mIIISlh4LVY6dnZ4.','2024-03-12 05:33:00','2024-03-12 05:33:00',NULL),(23,'dummy1','dummy1@email.com','$2b$12$3vvaFuutAHMZfmDs9AZE1O9JeHdnnorryQGYiWDzx.ul0RBbZ68aq','2024-03-12 05:33:25','2024-03-12 05:33:25',NULL),(24,'dummy1','dummy1@email.com','$2b$12$IT5zm8cFTONoBzGZ85baQ.2ES4vPe8u8ZuVZjFkkvGqFIlKVu7mGu','2024-03-12 05:33:34','2024-03-12 05:33:34',NULL),(25,'dummy1','dummy1@email.com','$2b$12$C4.jqvviMektjlihkGuuc.pJqGc6J2PyXWEY26u8Xk4F1Z8/rfT4C','2024-03-12 05:34:09','2024-03-12 05:34:09',NULL),(26,'dummy1','dummy1@email.com','$2b$12$KXZlaFDWJRfiWoqDBp7lFuJPMXC57mFmAnl8dBXqycbWDVqzGUs0G','2024-03-12 05:34:31','2024-03-12 05:34:31',NULL),(27,'dummy1','dummy1@email.com','$2b$12$YQ0WTa3.lVefxcygn9z4BOrRSbC7RvNWV9zYijrBctGh.gIWq8GPu','2024-03-13 13:06:58','2024-03-13 13:06:58',NULL),(28,'dummy3','dummy3@email.com','$2b$12$YzT6KdvoEGsId69kyE/wCuMJfKw5mFJ76fBTX8KP4At.MUmAX3BU.','2024-03-14 14:15:05','2024-03-14 14:15:05','Admin');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-16  0:02:37
